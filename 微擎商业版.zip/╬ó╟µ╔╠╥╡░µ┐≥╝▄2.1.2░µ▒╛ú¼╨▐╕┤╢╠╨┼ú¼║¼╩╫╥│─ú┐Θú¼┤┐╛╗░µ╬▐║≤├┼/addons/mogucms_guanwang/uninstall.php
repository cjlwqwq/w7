<?php
$sql =
"
";
pdo_query($sql);